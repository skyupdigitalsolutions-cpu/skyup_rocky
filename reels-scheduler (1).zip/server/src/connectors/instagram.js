import { env } from '../config/env.js';
import { ConnectorError } from './base.js';

// Instagram Graph publishing connector. Reuses the existing Meta app (Facebook
// Login). Unlike the metric connectors this one performs a WRITE (publishing) —
// but the write is still gated: it only fires when a ScheduledPost is due AND
// its publishMode allows it, and the whole flow no-ops in DRY_RUN.
//
// Publishing a Reel is a 3-step Graph dance:
//   1) POST /{ig-user-id}/media   media_type=REELS, video_url, caption  -> container id
//   2) GET  /{container-id}?fields=status_code   poll until FINISHED
//   3) POST /{ig-user-id}/media_publish  creation_id=<container>        -> media id
//
// sync() is a no-op so the Integrations page can render/connect it uniformly
// (it produces no MetricSnapshots).

const GRAPH = () => `https://graph.facebook.com/${env.META_API_VERSION}`;

export const instagramConnector = {
  provider: 'instagram',

  isConfigured() {
    return Boolean(env.META_APP_ID && env.META_APP_SECRET);
  },

  buildAuthUrl(client, state) {
    if (!this.isConfigured()) throw new ConnectorError('Instagram not configured', { code: 'not_configured' });
    const redirect = `${env.SERVER_PUBLIC_URL}/api/integrations/instagram/callback`;
    const scope = [
      'instagram_basic',
      'instagram_content_publish',
      'pages_show_list',
      'business_management',
    ].join(',');
    const url = new URL(`https://www.facebook.com/${env.META_API_VERSION}/dialog/oauth`);
    url.searchParams.set('client_id', env.META_APP_ID);
    url.searchParams.set('redirect_uri', redirect);
    url.searchParams.set('scope', scope);
    url.searchParams.set('state', state);
    url.searchParams.set('response_type', 'code');
    return url.toString();
  },

  async exchangeCode(code) {
    if (!this.isConfigured()) throw new ConnectorError('Instagram not configured', { code: 'not_configured' });
    const redirect = `${env.SERVER_PUBLIC_URL}/api/integrations/instagram/callback`;
    const tokenUrl = new URL(`${GRAPH()}/oauth/access_token`);
    tokenUrl.searchParams.set('client_id', env.META_APP_ID);
    tokenUrl.searchParams.set('client_secret', env.META_APP_SECRET);
    tokenUrl.searchParams.set('redirect_uri', redirect);
    tokenUrl.searchParams.set('code', code);
    const res = await fetch(tokenUrl);
    if (!res.ok) throw new ConnectorError(`Instagram token exchange failed: ${res.status}`);
    const data = await res.json();
    // NOTE(real): exchange for a long-lived token and resolve the IG business
    // account id from the connected Page, then store igUserId on the client.
    return {
      credentials: { accessToken: data.access_token },
      accountLabel: 'Instagram',
      externalAccountId: '',
      scopes: ['instagram_content_publish'],
    };
  },

  // No metric sync for this provider.
  async sync() {
    return { ok: true, snapshots: 0, reason: 'no_metric_sync', message: 'Instagram is a publishing channel (no metrics sync).' };
  },

  // ---- Publishing surface (used by services/reelsPublisher.js) --------------

  async createReelContainer({ igUserId, token, videoUrl, caption }) {
    const url = new URL(`${GRAPH()}/${igUserId}/media`);
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        media_type: 'REELS',
        video_url: videoUrl,
        caption: caption || '',
        access_token: token,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new ConnectorError(`IG container create failed: ${res.status} ${JSON.stringify(data?.error || data)}`);
    return data.id;
  },

  async getContainerStatus({ containerId, token }) {
    const url = new URL(`${GRAPH()}/${containerId}`);
    url.searchParams.set('fields', 'status_code,status');
    url.searchParams.set('access_token', token);
    const res = await fetch(url);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new ConnectorError(`IG container status failed: ${res.status}`);
    return data.status_code; // EXPIRED | ERROR | FINISHED | IN_PROGRESS | PUBLISHED
  },

  async publishContainer({ igUserId, token, containerId }) {
    const url = new URL(`${GRAPH()}/${igUserId}/media_publish`);
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ creation_id: containerId, access_token: token }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new ConnectorError(`IG publish failed: ${res.status} ${JSON.stringify(data?.error || data)}`);
    return data.id; // published media id
  },

  async getPermalink({ mediaId, token }) {
    try {
      const url = new URL(`${GRAPH()}/${mediaId}`);
      url.searchParams.set('fields', 'permalink');
      url.searchParams.set('access_token', token);
      const res = await fetch(url);
      const data = await res.json().catch(() => ({}));
      return res.ok ? data.permalink || '' : '';
    } catch {
      return '';
    }
  },
};
