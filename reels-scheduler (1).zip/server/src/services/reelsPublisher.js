import { ScheduledPost } from '../models/ScheduledPost.js';
import { Client } from '../models/Client.js';
import { Integration } from '../models/Integration.js';
import { instagramConnector } from '../connectors/instagram.js';
import { decryptSecret } from '../lib/crypto.js';
import { env } from '../config/env.js';
import { logger } from '../lib/logger.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Publish a single ScheduledPost that has already been CLAIMED (status set to
// 'processing' by the caller). Returns the updated post. Never throws for a
// publish failure — it records the failure on the post and schedules a retry.
export async function publishScheduledPost(postId) {
  const post = await ScheduledPost.findById(postId);
  if (!post) return null;

  post.attempts += 1;
  const caption = buildCaption(post);

  try {
    const dryRun = env.PUBLISH_DRY_RUN || !instagramConnector.isConfigured();

    if (dryRun) {
      // Offline simulation: exercises the full state machine with no Graph call.
      logger.info(`[reels] DRY_RUN publish for post ${post._id} (${post.client})`);
      await sleep(600);
      post.igContainerId = `dry_container_${Date.now()}`;
      post.igMediaId = `dry_media_${Date.now()}`;
      post.permalink = '';
      post.dryRun = true;
      finishPublished(post);
      await post.save();
      return post;
    }

    // --- Real publish ---------------------------------------------------------
    const client = await Client.findById(post.client).lean();
    const igUserId = client?.accountRefs?.instagramUserId;
    if (!igUserId) throw new Error('Client has no instagramUserId set (accountRefs.instagramUserId)');

    const integration = await Integration.findOne({
      client: post.client,
      provider: 'instagram',
      status: 'connected',
    }).select('+credentials');
    const enc = integration?.credentials?.get?.('accessToken');
    const token = enc ? decryptSecret(enc) : null;
    if (!token) throw new Error('Instagram not connected for this client');

    if (!post.media?.videoUrl) throw new Error('Post has no media.videoUrl');

    // 1) container
    const containerId = await instagramConnector.createReelContainer({
      igUserId,
      token,
      videoUrl: post.media.videoUrl,
      caption,
    });
    post.igContainerId = containerId;
    await post.save();

    // 2) wait for processing (reels transcode async). Poll up to ~5 min.
    const status = await waitForContainer(containerId, token);
    if (status !== 'FINISHED') throw new Error(`Container not ready (status=${status})`);

    // 3) publish
    const mediaId = await instagramConnector.publishContainer({ igUserId, token, containerId });
    post.igMediaId = mediaId;
    post.permalink = await instagramConnector.getPermalink({ mediaId, token });
    post.dryRun = false;
    finishPublished(post);
    await post.save();
    logger.info(`[reels] published post ${post._id} -> media ${mediaId}`);
    return post;
  } catch (err) {
    post.lastError = String(err.message || err).slice(0, 500);
    if (post.attempts < post.maxAttempts) {
      post.status = 'retry';
      post.nextRetryAt = new Date(Date.now() + backoffMs(post.attempts));
    } else {
      post.status = 'failed';
      post.nextRetryAt = null;
    }
    await post.save();
    logger.warn({ err: post.lastError }, `[reels] publish failed for post ${post._id} (attempt ${post.attempts})`);
    return post;
  }
}

async function waitForContainer(containerId, token, { timeoutMs = 5 * 60 * 1000, intervalMs = 5000 } = {}) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const status = await instagramConnector.getContainerStatus({ containerId, token });
    if (status === 'FINISHED') return 'FINISHED';
    if (status === 'ERROR' || status === 'EXPIRED') return status;
    await sleep(intervalMs);
  }
  return 'TIMEOUT';
}

function finishPublished(post) {
  post.status = 'published';
  post.publishedAt = new Date();
  post.lastError = '';
  post.nextRetryAt = null;
}

function buildCaption(post) {
  const tags = (post.hashtags || []).filter(Boolean).map((t) => (t.startsWith('#') ? t : `#${t}`));
  return [post.caption?.trim(), tags.join(' ')].filter(Boolean).join('\n\n');
}

const backoffMs = (attempt) => Math.min(60 * 60 * 1000, 5 * 60 * 1000 * attempt); // 5m,10m,15m…capped 1h
