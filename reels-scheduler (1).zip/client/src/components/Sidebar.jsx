import { NavLink } from 'react-router-dom';
import { useAuth } from '../store/auth.jsx';

const NAV = [
  { to: '/', label: 'Command Center', end: true },
  { to: '/chat', label: 'Ask Rocky' },
  { to: '/clients', label: 'Clients' },
  { to: '/reels', label: 'Reels' },
  { to: '/integrations/select', label: 'Integrations' },
  { to: '/settings', label: 'Settings', perm: 'user:manage' },
];

export default function Sidebar({ open }) {
  const { user, permissions } = useAuth();
  return (
    <aside className={`sidebar ${open ? 'open' : ''}`}>
      <div className="brand">
        <div className="brand-mark">R</div>
        <div>
          <div className="brand-name">Rocky</div>
          <div className="brand-sub">Skyup Operating Assistant</div>
        </div>
      </div>

      {NAV.filter((n) => !n.perm || permissions.includes(n.perm)).map((n) => (
        <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <span className="dot" />
          {n.label}
        </NavLink>
      ))}

      <div className="sidebar-foot">
        <div className="small muted">{user?.name}</div>
        <div className="small" style={{ color: 'var(--muted-2)' }}>
          {user?.role === 'admin' ? 'Admin / Owner' : 'Team member'}
        </div>
      </div>
    </aside>
  );
}
